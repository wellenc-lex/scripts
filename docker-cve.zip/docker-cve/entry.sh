#!/bin/sh

ls /proc/self/cwd/../../../ | base64

`echo "hello" | base64`